/**
 * Cloudflare Worker - Main Entry Point with HTML Caching
 * Modular ES Module Structure
 * OPTIMIZED: Moved helper functions to module level to avoid recreation per request
 * COLD START FIX: Uses warmupDB to initialize database early without blocking
 */

import { CORS, handleOptions } from './config/cors.js';
import { initDB, warmupDB } from './config/db.js';
import { VERSION, setVersion } from './config/constants.js';
import { routeApiRequest } from './router.js';
import { handleProductRouting } from './controllers/products.js';
import { handleSecureDownload, maybePurgeCache } from './controllers/admin.js';
import { cleanupExpired } from './controllers/whop.js';
import { generateBackupData, sendBackupEmail, createBackup as createBackupApi } from './controllers/backup.js';
import { generateProductSchema, generateCollectionSchema, generateVideoSchema, injectSchemaIntoHTML, generateBlogPostingSchema, generateQAPageSchema, generateBreadcrumbSchema, generateOrganizationSchema, generateWebSiteSchema } from './utils/schema.js';
import { getMimeTypeFromFilename } from './utils/upload-helper.js';
import { buildMinimalRobotsTxt, buildMinimalSitemapXml, getMinimalSEOSettings } from './controllers/seo-minimal.js';
import { getNoindexMetaTags, shouldNoindexUrl } from './controllers/noindex.js';
import { canonicalProductPath } from './utils/formatting.js';

// Inject analytics & verification meta tags (Google Analytics, Facebook Pixel, site verification)
import { injectAnalyticsAndMeta } from './controllers/analytics.js';

// Auth utilities
import { isAdminAuthed, createAdminSessionCookie, createLogoutCookie } from './utils/auth.js';


// =========================
// ADMIN AUTH HELPERS (Module Level - OPTIMIZED)
// =========================

function noStoreHeaders(extra = {}) {
  return {
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    'Pragma': 'no-cache',
    ...extra
  };
}

// Common automated scanner paths (WordPress/PHP/admin probes) that do not
// exist on this app. Fast-rejecting them avoids unnecessary subrequests and
// DB warmup work on every probe.
const SCANNER_PREFIXES = [
  '/wp-admin',
  '/wp-content',
  '/wp-includes',
  '/phpmyadmin',
  '/pma',
  '/adminer',
  '/mysql',
  '/xmlrpc.php',
  '/cgi-bin',
  '/vendor/',
  '/boaform',
  '/hnap1',
  '/.git',
  '/.env'
];

const SCANNER_PATH_RE = /\.(php[0-9]?|phtml|asp|aspx|jsp|cgi|env|ini|sql|bak|old|log|swp)$/i;
const DYNAMIC_SLUG_RE = /^[a-z0-9][a-z0-9-]{0,79}$/;
// Top-level `/api/{segment}` allowlist. Keep aligned with `src/router.js`.
const KNOWN_API_SEGMENTS = new Set([
  'admin',
  'backup',
  'blog',
  'blogs',
  'chat',
  'coupons',
  'debug',
  'forum',
  'health',
  'lead',
  'order',
  'orders',
  'page',
  'pages',
  'payment',
  'paypal',
  'product',
  'products',
  'purge-cache',
  'r2',
  'reviews',
  'settings',
  'time',
  'upload',
  'whop'
]);

function isLikelyScannerPath(pathname) {
  const p = String(pathname || '').toLowerCase();
  if (!p || p === '/') return false;

  if (SCANNER_PREFIXES.some((prefix) => p.startsWith(prefix))) return true;
  if (p.includes('/.git/') || p.includes('/.env')) return true;
  if (SCANNER_PATH_RE.test(p) && !p.endsWith('.html')) return true;

  return false;
}

function canLookupDynamicSlug(slug) {
  const s = String(slug || '').toLowerCase();
  return DYNAMIC_SLUG_RE.test(s);
}

function isKnownApiPath(pathname) {
  const p = String(pathname || '');
  if (!p.startsWith('/api/')) return true;
  const apiTail = p.slice('/api/'.length);
  const firstSegment = apiTail.split('/')[0].toLowerCase();
  return !!firstSegment && KNOWN_API_SEGMENTS.has(firstSegment);
}

function isMalformedNestedSlug(pathname, prefix) {
  const p = String(pathname || '');
  if (!p.startsWith(prefix) || p === prefix || p.includes('.')) return false;
  let slug = p.slice(prefix.length);
  if (slug.endsWith('/')) slug = slug.slice(0, -1);
  if (!slug) return false;
  if (slug.includes('/')) return true;
  return !canLookupDynamicSlug(slug);
}

// -------------------------------
// SEO helper functions
// -------------------------------
/**
 * Determine robots and canonical values for a given request.
 * - If a URL is marked as noindex via noindex patterns, robots is set to 'noindex, nofollow'.
 * - Otherwise defaults to 'index, follow'.
 * - Canonical URL is built from the base site URL (from seo_minimal settings or request origin)
 *   and the requested path, unless a product object is provided, in which case the canonical
 *   product path is used. Products may override canonical via `seo_canonical`.
 * @param {Object} env Cloudflare environment bindings
 * @param {Request} req Incoming request
 * @param {Object} opts Additional context: { path?: string, product?: Object }
 * @returns {Promise<{robots: string, canonical: string}>}
 */
async function getSeoForRequest(env, req, opts = {}) {
  const url = new URL(req.url);
  // Determine pathname from opts.path or request
  const pathname = opts.path || url.pathname || '/';

  // Default robots directive
  let robots = 'index, follow';
  // Check noindex patterns
  try {
    if (await shouldNoindexUrl(env, pathname)) {
      robots = 'noindex, nofollow';
    }
  } catch (e) {
    // ignore errors and fall back to default
  }

  // Get site URL from seo_minimal settings; fallback to request origin
  let baseUrl = url.origin;
  try {
    const res = await getMinimalSEOSettings(env);
    if (res && res.settings && res.settings.site_url) {
      baseUrl = res.settings.site_url;
    }
  } catch (e) {
    // ignore
  }

  // Build canonical
  let canonical = '';
  if (opts.product) {
    // Use product's canonical if provided, else construct via canonicalProductPath
    const product = opts.product;
    if (product.seo_canonical && String(product.seo_canonical).trim()) {
      canonical = String(product.seo_canonical).trim();
    } else {
      try {
        canonical = baseUrl + canonicalProductPath(product);
      } catch (e) {
        canonical = baseUrl + pathname;
      }
    }
  } else {
    canonical = baseUrl + pathname;
  }

  return { robots, canonical };
}

/**
 * Inject or update robots and canonical tags in an HTML string.
 * If a meta robots tag or canonical link already exists, it will be replaced.
 * Otherwise they will be appended before the closing </head> tag.
 * @param {string} html Original HTML
 * @param {string} robots Robots directive (e.g. 'index, follow' or 'noindex, nofollow')
 * @param {string} canonical Canonical URL to set, optional
 * @returns {string} Modified HTML with SEO tags injected
 */
function applySeoToHtml(html, robots, canonical) {
  if (!html) return html;
  // Inject robots meta tag
  if (robots) {
    const robotsRegex = /<meta\s+name=["']robots["'][^>]*>/i;
    const robotsTag = `<meta name="robots" content="${robots}">`;
    if (robotsRegex.test(html)) {
      html = html.replace(robotsRegex, robotsTag);
    } else {
      html = html.replace(/<\/head>/i, `${robotsTag}\n</head>`);
    }
  }
  // Inject canonical link
  if (canonical) {
    const canonicalRegex = /<link\s+rel=["']canonical["'][^>]*>/i;
    const canonicalTag = `<link rel="canonical" href="${canonical}">`;
    if (canonicalRegex.test(html)) {
      html = html.replace(canonicalRegex, canonicalTag);
    } else {
      html = html.replace(/<\/head>/i, `${canonicalTag}\n</head>`);
    }
  }
  return html;
}

// Blog post HTML template generator
function generateBlogPostHTML(blog, previousBlogs = [], comments = []) {
  const date = blog.created_at ? new Date(blog.created_at).toLocaleDateString('en-US', { 
    year: 'numeric', month: 'long', day: 'numeric' 
  }) : '';
  
  const prevBlogsHTML = previousBlogs.length > 0 ? `
    <div class="related-posts">
      <h3>Previous Posts</h3>
      <div class="related-grid">
        ${previousBlogs.map(p => `
          <a href="/blog/${p.slug}" class="related-card">
            <div class="related-thumb">
              <img src="${p.thumbnail_url || 'https://via.placeholder.com/300x169?text=No+Image'}" alt="${p.title}" loading="lazy">
            </div>
            <div class="related-content">
              <h4>${p.title}</h4>
              <p>${p.description ? (p.description.length > 80 ? p.description.substring(0, 80) + '...' : p.description) : ''}</p>
            </div>
          </a>
        `).join('')}
      </div>
    </div>
  ` : '';

  // Generate comments HTML
  const commentsHTML = comments.map(c => {
    const commentDate = c.created_at ? new Date(c.created_at).toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric'
    }) : '';
    const safeName = (c.name || 'Anonymous').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const safeComment = (c.comment || '').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
    return `
      <div class="comment-item">
        <div class="comment-header">
          <div class="comment-avatar">${safeName.charAt(0).toUpperCase()}</div>
          <div class="comment-info">
            <div class="comment-name">${safeName}</div>
            <div class="comment-date">${commentDate}</div>
          </div>
        </div>
        <div class="comment-text">${safeComment}</div>
      </div>
    `;
  }).join('');

  const safeTitle = (blog.title || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const safeDesc = (blog.seo_description || blog.description || '').substring(0, 160).replace(/"/g, '&quot;');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${blog.seo_title || blog.title} - WishesU</title>
  <meta name="description" content="${safeDesc}">
  <meta name="keywords" content="${blog.seo_keywords || ''}">
  <meta property="og:title" content="${safeTitle}">
  <meta property="og:description" content="${safeDesc}">
  <meta property="og:image" content="${blog.thumbnail_url || ''}">
  <meta property="og:type" content="article">
  <link rel="stylesheet" href="/css/style.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f5f5; line-height: 1.6; }
    
    .blog-hero {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px 20px;
    }
    .blog-hero-inner {
      max-width: 900px;
      margin: 0 auto;
      text-align: center;
    }
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: rgba(255,255,255,0.9);
      text-decoration: none;
      font-weight: 500;
      margin-bottom: 30px;
      transition: color 0.2s;
    }
    .back-link:hover { color: white; }
    .blog-hero h1 {
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 20px;
      line-height: 1.3;
    }
    .blog-meta {
      display: flex;
      justify-content: center;
      gap: 20px;
      opacity: 0.9;
      font-size: 1rem;
    }
    
    .blog-container {
      max-width: 900px;
      margin: -60px auto 0;
      padding: 0 20px 60px;
      position: relative;
      z-index: 10;
    }
    
    .blog-card {
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.15);
      overflow: hidden;
    }
    
    .blog-featured-image {
      width: 100%;
      aspect-ratio: 16/9;
      object-fit: cover;
    }
    
    .blog-body {
      padding: 40px;
    }
    
    .blog-content {
      font-size: 1.1rem;
      color: #374151;
      line-height: 1.8;
    }
    .blog-content h1, .blog-content h2, .blog-content h3, .blog-content h4 {
      color: #1f2937;
      margin: 30px 0 15px;
      line-height: 1.3;
    }
    .blog-content h1 { font-size: 2rem; }
    .blog-content h2 { font-size: 1.6rem; }
    .blog-content h3 { font-size: 1.3rem; }
    .blog-content p { margin: 15px 0; }
    .blog-content img {
      max-width: 100%;
      height: auto;
      border-radius: 8px;
      margin: 20px 0;
    }
    .blog-content a { color: #667eea; }
    .blog-content ul, .blog-content ol {
      margin: 15px 0;
      padding-left: 25px;
    }
    .blog-content li { margin: 8px 0; }
    .blog-content blockquote {
      border-left: 4px solid #667eea;
      margin: 20px 0;
      padding: 15px 25px;
      background: #f9fafb;
      font-style: italic;
      color: #4b5563;
    }
    .blog-content pre {
      background: #1f2937;
      color: #e5e7eb;
      padding: 20px;
      border-radius: 8px;
      overflow-x: auto;
      font-family: 'Monaco', 'Menlo', monospace;
      font-size: 0.9rem;
      margin: 20px 0;
    }
    .blog-content code {
      background: #f3f4f6;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: 'Monaco', 'Menlo', monospace;
      font-size: 0.9em;
    }
    .blog-content pre code {
      background: none;
      padding: 0;
    }
    
    /* Related Posts */
    .related-posts {
      margin-top: 50px;
      padding-top: 40px;
      border-top: 2px solid #e5e7eb;
    }
    .related-posts h3 {
      font-size: 1.5rem;
      color: #1f2937;
      margin-bottom: 25px;
      text-align: center;
    }
    .related-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 25px;
    }
    .related-card {
      background: #f9fafb;
      border-radius: 12px;
      overflow: hidden;
      text-decoration: none;
      transition: all 0.3s ease;
      display: flex;
      flex-direction: column;
    }
    .related-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    .related-thumb {
      aspect-ratio: 16/9;
      overflow: hidden;
    }
    .related-thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s;
    }
    .related-card:hover .related-thumb img {
      transform: scale(1.05);
    }
    .related-content {
      padding: 20px;
    }
    .related-content h4 {
      font-size: 1.1rem;
      color: #1f2937;
      margin: 0 0 10px;
      line-height: 1.4;
    }
    .related-content p {
      font-size: 0.9rem;
      color: #6b7280;
      margin: 0;
      line-height: 1.5;
    }
    
    /* Comments Section */
    .comments-section {
      margin-top: 50px;
      padding-top: 40px;
      border-top: 2px solid #e5e7eb;
    }
    .comments-section h3 {
      font-size: 1.5rem;
      color: #1f2937;
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .comment-count {
      background: #667eea;
      color: white;
      font-size: 0.9rem;
      padding: 4px 12px;
      border-radius: 20px;
    }
    
    .comments-list {
      display: flex;
      flex-direction: column;
      gap: 20px;
      margin-bottom: 40px;
    }
    .comment-item {
      background: #f9fafb;
      border-radius: 12px;
      padding: 20px;
    }
    .comment-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }
    .comment-avatar {
      width: 45px;
      height: 45px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1.2rem;
    }
    .comment-info { flex: 1; }
    .comment-name {
      font-weight: 600;
      color: #1f2937;
    }
    .comment-date {
      font-size: 0.85rem;
      color: #6b7280;
    }
    .comment-text {
      color: #374151;
      line-height: 1.6;
    }
    
    .no-comments {
      text-align: center;
      padding: 30px;
      color: #6b7280;
      background: #f9fafb;
      border-radius: 12px;
    }
    
    /* Comment Form */
    .comment-form-card {
      background: #f9fafb;
      border-radius: 12px;
      padding: 25px;
    }
    .comment-form-card h4 {
      font-size: 1.2rem;
      color: #1f2937;
      margin-bottom: 20px;
    }
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 15px;
    }
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .form-group.full { grid-column: span 2; }
    .form-group label {
      font-weight: 600;
      color: #374151;
      font-size: 0.9rem;
    }
    .form-group input,
    .form-group textarea {
      padding: 12px 15px;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      font-size: 1rem;
      transition: border-color 0.2s;
      font-family: inherit;
    }
    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #667eea;
    }
    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }
    .submit-btn {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .submit-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 8px 16px rgba(102, 126, 234, 0.4);
    }
    .submit-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .form-message {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .form-message.success {
      background: #d1fae5;
      color: #065f46;
      display: block;
    }
    .form-message.error {
      background: #fee2e2;
      color: #991b1b;
      display: block;
    }
    .form-message.warning {
      background: #fef3c7;
      color: #92400e;
      display: block;
    }
    
    .pending-notice {
      background: #fef3c7;
      color: #92400e;
      padding: 15px 20px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
      .blog-hero h1 { font-size: 1.8rem; }
      .blog-body { padding: 25px; }
      .blog-content { font-size: 1rem; }
      .related-grid { grid-template-columns: 1fr; }
      .form-row { grid-template-columns: 1fr; }
      .form-group.full { grid-column: span 1; }
    }
    
    ${blog.custom_css || ''}
  </style>
</head>
<body>
  <script src="/js/global-components.js"></script>
  <div class="blog-hero">
    <div class="blog-hero-inner">
      <a href="/blog/" class="back-link">← Back to Blog</a>
      <h1>${safeTitle}</h1>
      ${date ? `<div class="blog-meta"><span>📅 ${date}</span></div>` : ''}
    </div>
  </div>
  
  <div class="blog-container">
    <article class="blog-card">
      ${blog.thumbnail_url ? `<img src="${blog.thumbnail_url}" alt="${safeTitle}" class="blog-featured-image">` : ''}
      <div class="blog-body">
        <div class="blog-content">
          ${blog.content || ''}
        </div>
        
        <!-- Comments Section -->
        <div class="comments-section">
          <h3>💬 Comments <span class="comment-count">${comments.length}</span></h3>
          
          ${comments.length > 0 ? `
            <div class="comments-list">
              ${commentsHTML}
            </div>
          ` : `
            <div class="no-comments">
              <p>No comments yet. Be the first to share your thoughts!</p>
            </div>
          `}
          
          <!-- Comment Form -->
          <div class="comment-form-card">
            <h4>Leave a Comment</h4>
            <div id="form-message" class="form-message"></div>
            <div id="pending-notice" class="pending-notice" style="display:none;">
              ⏳ You have a comment awaiting approval. Please wait for it to be approved before posting another.
            </div>
            <form id="comment-form">
              <input type="hidden" id="blog-id" value="${blog.id}">
              <div class="form-row">
                <div class="form-group">
                  <label for="comment-name">Name * <small style="color:#6b7280;font-weight:normal">(max 50)</small></label>
                  <input type="text" id="comment-name" placeholder="Your name" required maxlength="50">
                </div>
                <div class="form-group">
                  <label for="comment-email">Email * <small style="color:#6b7280;font-weight:normal">(max 100)</small></label>
                  <input type="email" id="comment-email" placeholder="your@email.com" required maxlength="100">
                </div>
              </div>
              <div class="form-group full">
                <label for="comment-text">Comment * <small style="color:#6b7280;font-weight:normal">(3-2000 chars)</small></label>
                <textarea id="comment-text" placeholder="Write your comment here..." required minlength="3" maxlength="2000"></textarea>
                <div style="text-align:right;font-size:0.75rem;color:#6b7280;margin-top:2px"><span id="comment-count">0</span>/2000</div>
              </div>
              <button type="submit" class="submit-btn" id="submit-btn">Submit Comment</button>
            </form>
          </div>
        </div>
        
        ${prevBlogsHTML}
      </div>
    </article>
  </div>
  
  <script>
    const blogId = ${blog.id};
    const form = document.getElementById('comment-form');
    const formMessage = document.getElementById('form-message');
    const pendingNotice = document.getElementById('pending-notice');
    const submitBtn = document.getElementById('submit-btn');
    const emailInput = document.getElementById('comment-email');
    
    // Character counter for comment
    document.getElementById('comment-text').addEventListener('input', function() {
      document.getElementById('comment-count').textContent = this.value.length;
    });
    
    // Check for pending comment when email is entered
    let checkTimeout;
    emailInput.addEventListener('blur', async function() {
      const email = this.value.trim();
      if (!email) return;
      
      clearTimeout(checkTimeout);
      checkTimeout = setTimeout(async () => {
        try {
          const res = await fetch('/api/blog/comments/check-pending', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ blog_id: blogId, email: email })
          });
          const data = await res.json();
          
          if (data.hasPending) {
            pendingNotice.style.display = 'block';
            submitBtn.disabled = true;
          } else {
            pendingNotice.style.display = 'none';
            submitBtn.disabled = false;
          }
        } catch (err) {
          console.error('Check pending error:', err);
        }
      }, 500);
    });
    
    // Submit comment
    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const name = document.getElementById('comment-name').value.trim();
      const email = document.getElementById('comment-email').value.trim();
      const comment = document.getElementById('comment-text').value.trim();
      
      if (!name || !email || !comment) {
        showMessage('Please fill in all fields.', 'error');
        return;
      }
      
      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting...';
      
      try {
        const res = await fetch('/api/blog/comments/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            blog_id: blogId,
            name: name,
            email: email,
            comment: comment
          })
        });
        const data = await res.json();
        
        if (data.success) {
          showMessage(data.message || 'Comment submitted successfully! It will appear after admin approval.', 'success');
          form.reset();
          pendingNotice.style.display = 'block';
          submitBtn.disabled = true;
        } else {
          if (data.hasPending) {
            pendingNotice.style.display = 'block';
            submitBtn.disabled = true;
          }
          showMessage(data.error || 'Failed to submit comment.', 'error');
        }
      } catch (err) {
        console.error('Submit error:', err);
        showMessage('An error occurred. Please try again.', 'error');
      }
      
      submitBtn.textContent = 'Submit Comment';
    });
    
    function showMessage(msg, type) {
      formMessage.textContent = msg;
      formMessage.className = 'form-message ' + type;
      formMessage.style.display = 'block';
      
      if (type === 'success') {
        setTimeout(() => {
          formMessage.style.display = 'none';
        }, 5000);
      }
    }
  </script>
  ${blog.custom_js ? `<script>${blog.custom_js}</script>` : ''}
</body>
</html>`;
}

// Forum question page HTML template generator
function generateForumQuestionHTML(question, replies = [], sidebar = {}) {
  const date = question.created_at ? new Date(question.created_at).toLocaleDateString('en-US', { 
    year: 'numeric', month: 'long', day: 'numeric' 
  }) : '';
  
  const safeTitle = (question.title || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const safeContent = (question.content || '').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  
  // Generate replies HTML
  const repliesHTML = replies.map(r => {
    const replyDate = r.created_at ? new Date(r.created_at).toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric'
    }) : '';
    const safeName = (r.name || 'Anonymous').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const safeReply = (r.content || '').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
    return `
      <div class="reply-item">
        <div class="reply-header">
          <div class="reply-avatar">${safeName.charAt(0).toUpperCase()}</div>
          <div class="reply-info">
            <div class="reply-name">${safeName}</div>
            <div class="reply-date">${replyDate}</div>
          </div>
        </div>
        <div class="reply-content">${safeReply}</div>
      </div>
    `;
  }).join('');

  // Sidebar products
  const productsHTML = (sidebar.products || []).map(p => `
    <a href="/product-${p.id}/${p.slug || p.id}" class="sidebar-card">
      <img src="${p.thumbnail_url || 'https://via.placeholder.com/150x84?text=Product'}" alt="${p.title}">
      <div class="sidebar-card-info">
        <div class="sidebar-card-title">${(p.title || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
        <div class="sidebar-card-price">$${p.sale_price || p.normal_price || 0}</div>
      </div>
    </a>
  `).join('');

  // Sidebar blogs
  const blogsHTML = (sidebar.blogs || []).map(b => `
    <a href="/blog/${b.slug}" class="sidebar-card">
      <img src="${b.thumbnail_url || 'https://via.placeholder.com/150x84?text=Blog'}" alt="${b.title}">
      <div class="sidebar-card-info">
        <div class="sidebar-card-title">${(b.title || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
      </div>
    </a>
  `).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${safeTitle} - Forum - WishesU</title>
  <meta name="description" content="${safeTitle}">
  <link rel="stylesheet" href="/css/style.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f5f5; line-height: 1.6; }
    
    .forum-hero {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      padding: 40px 20px;
    }
    .forum-hero-inner {
      max-width: 1200px;
      margin: 0 auto;
      text-align: center;
    }
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: rgba(255,255,255,0.9);
      text-decoration: none;
      font-weight: 500;
      margin-bottom: 20px;
      transition: color 0.2s;
    }
    .back-link:hover { color: white; }
    .forum-hero h1 {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 15px;
      line-height: 1.3;
    }
    .forum-meta {
      display: flex;
      justify-content: center;
      gap: 20px;
      opacity: 0.9;
      font-size: 0.95rem;
    }
    
    .forum-layout {
      max-width: 1200px;
      margin: -40px auto 0;
      padding: 0 20px 60px;
      display: grid;
      grid-template-columns: 200px 1fr 200px;
      gap: 30px;
      position: relative;
      z-index: 10;
    }
    
    .sidebar {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .sidebar-section h4 {
      font-size: 0.9rem;
      color: #6b7280;
      margin-bottom: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .sidebar-card {
      display: block;
      background: white;
      border-radius: 10px;
      overflow: hidden;
      text-decoration: none;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      transition: all 0.3s;
      margin-bottom: 12px;
    }
    .sidebar-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 16px rgba(0,0,0,0.15);
    }
    .sidebar-card img {
      width: 100%;
      aspect-ratio: 16/9;
      object-fit: cover;
    }
    .sidebar-card-info {
      padding: 12px;
    }
    .sidebar-card-title {
      font-size: 0.85rem;
      font-weight: 600;
      color: #1f2937;
      line-height: 1.3;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .sidebar-card-price {
      color: #10b981;
      font-weight: 700;
      margin-top: 5px;
    }
    
    .main-content {
      min-width: 0;
    }
    
    .question-card {
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.15);
      overflow: hidden;
    }
    
    .question-body {
      padding: 35px;
    }
    
    .question-author {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 25px;
      padding-bottom: 20px;
      border-bottom: 2px solid #e5e7eb;
    }
    .author-avatar {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1.3rem;
    }
    .author-info { flex: 1; }
    .author-name {
      font-weight: 600;
      color: #1f2937;
      font-size: 1.1rem;
    }
    .author-date {
      font-size: 0.9rem;
      color: #6b7280;
    }
    
    .question-content {
      font-size: 1.1rem;
      color: #374151;
      line-height: 1.8;
    }
    
    /* Replies Section */
    .replies-section {
      margin-top: 40px;
      padding-top: 30px;
      border-top: 2px solid #e5e7eb;
    }
    .replies-section h3 {
      font-size: 1.3rem;
      color: #1f2937;
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .reply-count-badge {
      background: #10b981;
      color: white;
      font-size: 0.85rem;
      padding: 4px 12px;
      border-radius: 20px;
    }
    
    .replies-list {
      display: flex;
      flex-direction: column;
      gap: 20px;
      margin-bottom: 35px;
    }
    .reply-item {
      background: #f9fafb;
      border-radius: 12px;
      padding: 20px;
      border-left: 4px solid #10b981;
    }
    .reply-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }
    .reply-avatar {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1rem;
    }
    .reply-info { flex: 1; }
    .reply-name {
      font-weight: 600;
      color: #1f2937;
    }
    .reply-date {
      font-size: 0.85rem;
      color: #6b7280;
    }
    .reply-content {
      color: #374151;
      line-height: 1.6;
    }
    
    .no-replies {
      text-align: center;
      padding: 30px;
      color: #6b7280;
      background: #f9fafb;
      border-radius: 12px;
    }
    
    /* Reply Form */
    .reply-form-card {
      background: #f9fafb;
      border-radius: 12px;
      padding: 25px;
    }
    .reply-form-card h4 {
      font-size: 1.1rem;
      color: #1f2937;
      margin-bottom: 20px;
    }
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 15px;
    }
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .form-group.full { grid-column: span 2; }
    .form-group label {
      font-weight: 600;
      color: #374151;
      font-size: 0.9rem;
    }
    .form-group input,
    .form-group textarea {
      padding: 12px 15px;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      font-size: 1rem;
      transition: border-color 0.2s;
      font-family: inherit;
    }
    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #10b981;
    }
    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }
    .submit-btn {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .submit-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 8px 16px rgba(16, 185, 129, 0.4);
    }
    .submit-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .form-message {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .form-message.success { background: #d1fae5; color: #065f46; display: block; }
    .form-message.error { background: #fee2e2; color: #991b1b; display: block; }
    
    .pending-notice {
      background: #fef3c7;
      color: #92400e;
      padding: 15px 20px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 20px;
    }
    
    @media (max-width: 1024px) {
      .forum-layout {
        grid-template-columns: 1fr;
      }
      .sidebar { display: none; }
    }
    
    @media (max-width: 768px) {
      .forum-hero h1 { font-size: 1.5rem; }
      .question-body { padding: 25px; }
      .form-row { grid-template-columns: 1fr; }
      .form-group.full { grid-column: span 1; }
    }
  </style>
</head>
<body>
  <script src="/js/global-components.js"></script>
  <div class="forum-hero">
    <div class="forum-hero-inner">
      <a href="/forum/" class="back-link">← Back to Forum</a>
      <h1>${safeTitle}</h1>
      <div class="forum-meta">
        <span>👤 ${(question.name || 'Anonymous').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>
        ${date ? `<span>📅 ${date}</span>` : ''}
        <span>💬 ${replies.length} ${replies.length === 1 ? 'Reply' : 'Replies'}</span>
      </div>
    </div>
  </div>
  
  <div class="forum-layout">
    <!-- Left Sidebar - Products -->
    <div class="sidebar">
      <div class="sidebar-section">
        <h4>📦 Products</h4>
        ${productsHTML || '<p style="color:#9ca3af;font-size:0.9rem;">No products</p>'}
      </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
      <div class="question-card">
        <div class="question-body">
          <div class="question-author">
            <div class="author-avatar">${(question.name || 'A').charAt(0).toUpperCase()}</div>
            <div class="author-info">
              <div class="author-name">${(question.name || 'Anonymous').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
              <div class="author-date">${date}</div>
            </div>
          </div>
          
          <div class="question-content">${safeContent}</div>
          
          <!-- Replies Section -->
          <div class="replies-section">
            <h3>💬 Replies <span class="reply-count-badge">${replies.length}</span></h3>
            
            ${replies.length > 0 ? `
              <div class="replies-list">${repliesHTML}</div>
            ` : `
              <div class="no-replies">
                <p>No replies yet. Be the first to help!</p>
              </div>
            `}
            
            <!-- Reply Form -->
            <div class="reply-form-card">
              <h4>Post a Reply</h4>
              <div id="form-message" class="form-message"></div>
              <div id="pending-notice" class="pending-notice" style="display:none;">
                ⏳ You have a pending question or reply awaiting approval. Please wait for it to be approved.
              </div>
              <form id="reply-form">
                <input type="hidden" id="question-id" value="${question.id}">
                <div class="form-row">
                  <div class="form-group">
                    <label for="reply-name">Name *</label>
                    <input type="text" id="reply-name" placeholder="Your name" required>
                  </div>
                  <div class="form-group">
                    <label for="reply-email">Email *</label>
                    <input type="email" id="reply-email" placeholder="your@email.com" required>
                  </div>
                </div>
                <div class="form-group full">
                  <label for="reply-content">Your Reply *</label>
                  <textarea id="reply-content" placeholder="Write your helpful reply..." required></textarea>
                </div>
                <button type="submit" class="submit-btn" id="submit-btn">Submit Reply</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Right Sidebar - Blogs -->
    <div class="sidebar">
      <div class="sidebar-section">
        <h4>📝 Blog Posts</h4>
        ${blogsHTML || '<p style="color:#9ca3af;font-size:0.9rem;">No posts</p>'}
      </div>
    </div>
  </div>
  
  <script>
    const questionId = ${question.id};
    const form = document.getElementById('reply-form');
    const formMessage = document.getElementById('form-message');
    const pendingNotice = document.getElementById('pending-notice');
    const submitBtn = document.getElementById('submit-btn');
    const emailInput = document.getElementById('reply-email');
    
    // Check for pending when email entered
    let checkTimeout;
    emailInput.addEventListener('blur', async function() {
      const email = this.value.trim();
      if (!email) return;
      
      clearTimeout(checkTimeout);
      checkTimeout = setTimeout(async () => {
        try {
          const res = await fetch('/api/forum/check-pending', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
          });
          const data = await res.json();
          
          if (data.hasPending) {
            pendingNotice.style.display = 'block';
            submitBtn.disabled = true;
          } else {
            pendingNotice.style.display = 'none';
            submitBtn.disabled = false;
          }
        } catch (err) {
          console.error('Check pending error:', err);
        }
      }, 500);
    });
    
    // Submit reply
    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const name = document.getElementById('reply-name').value.trim();
      const email = document.getElementById('reply-email').value.trim();
      const content = document.getElementById('reply-content').value.trim();
      
      if (!name || !email || !content) {
        showMessage('Please fill in all fields.', 'error');
        return;
      }
      
      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting...';
      
      try {
        const res = await fetch('/api/forum/submit-reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question_id: questionId,
            name: name,
            email: email,
            content: content
          })
        });
        const data = await res.json();
        
        if (data.success) {
          showMessage(data.message || 'Reply submitted! It will appear after admin approval.', 'success');
          form.reset();
          pendingNotice.style.display = 'block';
          submitBtn.disabled = true;
        } else {
          if (data.hasPending) {
            pendingNotice.style.display = 'block';
            submitBtn.disabled = true;
          }
          showMessage(data.error || 'Failed to submit reply.', 'error');
        }
      } catch (err) {
        console.error('Submit error:', err);
        showMessage('An error occurred. Please try again.', 'error');
      }
      
      submitBtn.textContent = 'Submit Reply';
    });
    
    function showMessage(msg, type) {
      formMessage.textContent = msg;
      formMessage.className = 'form-message ' + type;
      formMessage.style.display = 'block';
      
      if (type === 'success') {
        setTimeout(() => { formMessage.style.display = 'none'; }, 5000);
      }
    }
  </script>
</body>
</html>`;
}

export default {
  async fetch(req, env, ctx) {
    setVersion(env.VERSION);
    const url = new URL(req.url);
    // Normalize the request path
    let path = url.pathname.replace(/\/+/g, '/');
    if (!path.startsWith('/')) {
      path = '/' + path;
    }
    const method = req.method;

    // Fast reject obvious scanner/bot probes before any expensive work.
    if ((method === 'GET' || method === 'HEAD' || method === 'POST') && isLikelyScannerPath(path)) {
      return new Response('Not found', {
        status: 404,
        headers: {
          'Cache-Control': 'public, max-age=300',
          'X-Worker-Version': VERSION
        }
      });
    }

    // Fast reject unknown API probes to avoid unnecessary DB initialization.
    if (method !== 'OPTIONS' && path.startsWith('/api/') && !isKnownApiPath(path)) {
      return new Response(JSON.stringify({ error: 'Not found' }), {
        status: 404,
        headers: {
          ...CORS,
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'public, max-age=300',
          'X-Worker-Version': VERSION
        }
      });
    }

    // Fast reject malformed blog/forum detail URLs before any DB warmup work.
    if ((method === 'GET' || method === 'HEAD') && (
      isMalformedNestedSlug(path, '/blog/') ||
      isMalformedNestedSlug(path, '/forum/')
    )) {
      return new Response('Not found', {
        status: 404,
        headers: {
          'Cache-Control': 'public, max-age=300',
          'X-Worker-Version': VERSION
        }
      });
    }

    // COLD START FIX: Start DB initialization early and WAIT for critical paths
    // For API routes and dynamic pages, we need the DB ready before processing
    const requiresDB = path.startsWith('/api/') || 
                       path.startsWith('/blog/') || 
                       path.startsWith('/forum/') ||
                       path.startsWith('/product-') ||
                       path.startsWith('/admin/') ||
                       path === '/' ||
                       path === '/index.html';
    
    if (env.DB) {
      if (requiresDB) {
        // Wait for DB to be ready for critical paths (with timeout protection)
        try {
          await Promise.race([
            initDB(env),
            new Promise((_, reject) => setTimeout(() => reject(new Error('DB init timeout')), 4000))
          ]);
        } catch (e) {
          console.warn('DB init delayed:', e.message);
          // Continue anyway - the request handler will retry if needed
        }
      } else {
        // For static assets, warm up in background without blocking
        warmupDB(env, ctx);
      }
    }

// Route flags (computed once per request)
const isAdminUI = (path === '/admin' || path === '/admin/' || path.startsWith('/admin/'));
const isAdminAPI = path.startsWith('/api/admin/');
const isLoginRoute = (path === '/admin/login' || path === '/admin/login/');
const isLogoutRoute = (path === '/admin/logout' || path === '/admin/logout/');

// Some admin-only pages live outside /admin (legacy routes used by dashboard links)
const isAdminProtectedPage = (
  path === '/order-detail' ||
  path === '/order-detail/' ||
  path === '/order-detail.html'
);

async function requireAdmin() {
  const ok = await isAdminAuthed(req, env);
  if (ok) return null;

  if (isAdminAPI) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { ...CORS, 'Content-Type': 'application/json' }
    });
  }

  return Response.redirect(new URL('/admin/login', req.url).toString(), 302);
}

// Serve login page (GET)
if (isLoginRoute && method === 'GET') {
  // Already logged in? Send to admin.
  if (await isAdminAuthed(req, env)) {
    return Response.redirect(new URL('/admin', req.url).toString(), 302);
  }

  if (env.ASSETS) {
    const r = await env.ASSETS.fetch(new Request(new URL('/admin/login.html', req.url)));
    const h = new Headers(r.headers); h.set('Alt-Svc', 'clear');
    h.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    h.set('Pragma', 'no-cache');
    return new Response(r.body, { status: r.status, statusText: r.statusText, headers: h });
  }
  return new Response('Login page not found', { status: 404, headers: noStoreHeaders() });
}

// Handle login (POST)
if (isLoginRoute && method === 'POST') {
  const form = await req.formData();
  const email = (form.get('email') || '').toString().trim();
  const password = (form.get('password') || '').toString();

  if (!env.ADMIN_EMAIL || !env.ADMIN_PASSWORD || !env.ADMIN_SESSION_SECRET) {
    return new Response('Admin login is not configured (missing secrets).', { status: 500, headers: noStoreHeaders() });
  }


  if (email === (env.ADMIN_EMAIL || '') && password === (env.ADMIN_PASSWORD || '')) {
    const cookieVal = await createAdminSessionCookie(env);

    return new Response(null, {
      status: 302,
      headers: noStoreHeaders({
        'Set-Cookie': cookieVal,
        'Location': new URL('/admin', req.url).toString()
      })
    });
  }

  return new Response('Invalid login', {
    status: 401,
    headers: noStoreHeaders({
      'Set-Cookie': createLogoutCookie()
    })
  });
}

// Handle logout
if (isLogoutRoute) {
  return new Response(null, {
    status: 302,
    headers: noStoreHeaders({
      'Set-Cookie': createLogoutCookie(),
      'Location': new URL('/admin/login', req.url).toString()
    })
  });
}

// Protect admin UI + APIs + admin-only pages
if ((isAdminUI || isAdminAPI || isAdminProtectedPage) && !isLoginRoute) {
  const gate = await requireAdmin();
  if (gate) return gate;
}



    // Auto-purge cache on version change (only for admin/webhook routes)
    const shouldPurgeCache = (path.startsWith('/admin') || path.startsWith('/api/admin/') || path.startsWith('/api/whop/webhook')) && !path.startsWith('/admin/login') && !path.startsWith('/admin/logout');
    if (shouldPurgeCache) {
      await maybePurgeCache(env, initDB);
    }

    // Handle OPTIONS preflight
    if (method === 'OPTIONS') {
      return handleOptions(req);
    }

    // OPTIMIZATION: Fast path for static assets - skip all dynamic processing
    // These files don't need DB, SEO injection, or any processing
    const staticExtensions = /\.(css|js|ico|png|jpg|jpeg|gif|svg|webp|woff|woff2|ttf|eot|mp4|webm|mp3|pdf)$/i;
    if ((method === 'GET' || method === 'HEAD') && staticExtensions.test(path) && env.ASSETS) {
      const assetResp = await env.ASSETS.fetch(req);
      if (assetResp.status === 200) {
        const headers = new Headers(assetResp.headers); headers.set('Alt-Svc', 'clear');
        // Cache static assets aggressively, but avoid long-lived caching for admin assets
        // so UI updates show up without requiring a manual hard refresh.
        const isAdminAsset = path.startsWith('/js/admin/') || path.startsWith('/css/admin/');
        if (isAdminAsset) {
          headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
        } else if (!headers.has('Cache-Control')) {
          headers.set('Cache-Control', 'public, max-age=31536000, immutable');
        }
        headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
        return new Response(assetResp.body, { status: 200, headers });
      }
      // If not found, fall through to normal processing
    }

    // HEALTH CHECK ENDPOINT - For external warming services (UptimeRobot, cron-job.org)
    // This endpoint warms up DB and returns status
    // IMPROVED: Always initialize DB on health checks to ensure it's ready
    if (path === '/api/health' || path === '/_health') {
      const startTime = Date.now();
      let dbStatus = 'not_configured';

      if (env.DB) {
        try {
          // Force DB initialization on every health check
          await initDB(env);
          await env.DB.prepare('SELECT 1 as health').first();
          dbStatus = 'healthy';
        } catch (e) {
          dbStatus = 'error: ' + e.message;
        }
      }

      return new Response(JSON.stringify({
        status: 'ok',
        version: VERSION,
        db: dbStatus,
        responseTime: Date.now() - startTime + 'ms',
        timestamp: new Date().toISOString()
      }), {
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store'
        }
      });
    }

    // Dynamic robots.txt + sitemap.xml (Minimal SEO 2025 - Google Standards)
    if ((method === 'GET' || method === 'HEAD')) {
      if (path === '/.well-known/apple-developer-merchantid-domain-association') {
        if (env.ASSETS) {
          // Try canonical Apple Pay verification path first.
          let assetResp = await env.ASSETS.fetch(new Request(new URL('/.well-known/apple-developer-merchantid-domain-association', req.url)));
          // Fallback for environments that skip dot-directories during asset upload.
          if (assetResp.status !== 200) {
            assetResp = await env.ASSETS.fetch(new Request(new URL('/apple-developer-merchantid-domain-association', req.url)));
          }
          if (assetResp.status === 200) {
            const txt = await assetResp.text();
            return new Response(txt.trim(), {
              status: 200,
              headers: {
                'Content-Type': 'text/plain; charset=utf-8',
                'Cache-Control': 'public, max-age=300'
              }
            });
          }
        }
        return new Response('Not found', { status: 404 });
      }

      if (path === '/robots.txt') {
        if (env.DB) await initDB(env);
        const txt = await buildMinimalRobotsTxt(env, req);
        return new Response(txt, {
          status: 200,
          headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'public, max-age=300'
          }
        });
      }

      if (path === '/sitemap.xml') {
        if (env.DB) await initDB(env);
        const sm = await buildMinimalSitemapXml(env, req);
        return new Response(sm.body, {
          status: 200,
          headers: {
            'Content-Type': (sm.contentType || 'application/xml') + '; charset=utf-8',
            'Cache-Control': 'public, max-age=300'
          }
        });
      }
    }

    try {
      // Private asset: never serve the raw product template directly
      if ((method === 'GET' || method === 'HEAD') && (path === '/_product_template.tpl' || path === '/_product_template' || path === '/_product_template.html')) {
        return new Response('Not found', { status: 404 });
      }

      // ----- CANONICAL PRODUCT URLs -----
      if ((method === 'GET' || method === 'HEAD') && (path === '/product' || path.startsWith('/product/') || path.startsWith('/product-'))) {
        // BOT PROTECTION: Quick Regex Validation to prevent DB hits for invalid URLs
        // Valid patterns: /product, /product/slug, /product-123, /product-123/slug
        // Adjusted regex to allow any characters in slug (encoded, unicode, etc)
        const isValidFormat =
          path === '/product' ||
          path === '/product/' ||
          /^\/product\/[^/]+$/.test(path) ||
          /^\/product-\d+(\/.*)?$/.test(path);

        if (!isValidFormat) {
          return new Response('Not found', { status: 404 });
        }

        if (env.DB) {
          await initDB(env);
          const redirect = await handleProductRouting(env, url, path);
          if (redirect) return redirect;
        }
      }

      // ----- BLOG POST PAGES -----
      if ((method === 'GET' || method === 'HEAD') && path.startsWith('/blog/') && path !== '/blog/' && !path.includes('.')) {
        const slug = path.replace('/blog/', '').replace(/\/$/, '');
        // Only attempt to serve from cache for GET requests. HEAD requests should
        // still hit the cache API to return headers quickly without body.
        if (method === 'GET' && caches && caches.default) {
          try {
            const cacheKey = new Request(req.url, { method: 'GET' });
            const cachedResp = await caches.default.match(cacheKey);
            if (cachedResp) {
              return cachedResp;
            }
          } catch (err) {
            // Cache lookup failure should not break page rendering
            console.warn('Blog cache match error:', err);
          }
        }
        if (slug && env.DB) {
          try {
            await initDB(env);
            const blog = await env.DB.prepare(`
              SELECT * FROM blogs WHERE slug = ? AND status = 'published'
            `).bind(slug).first();
            
            if (blog) {
              // Run all queries in parallel for better CPU efficiency
              const [prevResult, commentsResult, seo] = await Promise.all([
                // Get previous 2 blog posts (before current one)
                env.DB.prepare(`
                  SELECT id, title, slug, description, thumbnail_url, created_at
                  FROM blogs 
                  WHERE status = 'published' AND id < ?
                  ORDER BY id DESC
                  LIMIT 2
                `).bind(blog.id).all(),
                // Get approved comments
                env.DB.prepare(`
                  SELECT id, name, comment, created_at
                  FROM blog_comments 
                  WHERE blog_id = ? AND status = 'approved'
                  ORDER BY created_at DESC
                `).bind(blog.id).all(),
                // Get SEO settings
                getSeoForRequest(env, req, { path })
              ]);
              
              const previousBlogs = prevResult.results || [];
              const comments = commentsResult.results || [];
              const htmlRaw = generateBlogPostHTML(blog, previousBlogs, comments);
              let html = applySeoToHtml(htmlRaw, seo.robots, seo.canonical);

              // Fix 7: Inject BlogPosting JSON-LD schema
              try {
                const blogSchemaJson = generateBlogPostingSchema(blog, url.origin);
                html = html.replace('</head>', `<script type="application/ld+json">${blogSchemaJson}</script>\n</head>`);
              } catch (_) {}

              // Fix 7: Add og:url to blog pages
              try {
                const ogUrlTag = `<meta property="og:url" content="${seo.canonical}">`;
                html = html.replace('</head>', `${ogUrlTag}\n</head>`);
              } catch (_) {}

              // Fix 9: Add BreadcrumbList to blog pages
              try {
                const breadcrumbJson = generateBreadcrumbSchema([
                  { name: 'Home', url: url.origin },
                  { name: 'Blog', url: `${url.origin}/blog` },
                  { name: blog.title || '', url: seo.canonical }
                ]);
                html = html.replace('</head>', `<script type="application/ld+json">${breadcrumbJson}</script>\n</head>`);
              } catch (_) {}

              // Inject analytics scripts and verification meta tags
              try {
                html = await injectAnalyticsAndMeta(env, html);
              } catch (e) {}

              const resp = new Response(html, {
                status: 200,
                headers: {
                  'Content-Type': 'text/html; charset=utf-8',
                  'X-Worker-Version': VERSION,
                  'X-Robots-Tag': seo.robots,
                  // Set a short max-age to hint caches while ensuring updates propagate
                  'Cache-Control': 'public, max-age=120'
                }
              });
              // Store in caches.default only for GET requests
              if (method === 'GET' && caches && caches.default) {
                try {
                  const cacheKey = new Request(req.url, { method: 'GET' });
                  // We clone to avoid the body being locked
                  await caches.default.put(cacheKey, resp.clone());
                } catch (err) {
                  console.warn('Blog cache put error:', err);
                }
              }
              return resp;
            }
          } catch (e) {
            console.error('Blog fetch error:', e);
          }
        }
      }

      // ----- FORUM QUESTION PAGES -----
      if ((method === 'GET' || method === 'HEAD') && path.startsWith('/forum/') && path !== '/forum/' && !path.includes('.')) {
        const slug = path.replace('/forum/', '').replace(/\/$/, '');
        // Try to serve from cache for GET requests
        if (method === 'GET' && caches && caches.default) {
          try {
            const cacheKey = new Request(req.url, { method: 'GET' });
            const cachedResp = await caches.default.match(cacheKey);
            if (cachedResp) {
              return cachedResp;
            }
          } catch (err) {
            console.warn('Forum cache match error:', err);
          }
        }
        if (slug && env.DB) {
          try {
            await initDB(env);
            const question = await env.DB.prepare(`
              SELECT * FROM forum_questions WHERE slug = ? AND status = 'approved'
            `).bind(slug).first();
            
            if (question) {
              // Run all queries in parallel for better CPU efficiency
              const [repliesResult, productsResult, blogsResult, seo] = await Promise.all([
                // Get approved replies
                env.DB.prepare(`
                  SELECT id, name, content, created_at
                  FROM forum_replies 
                  WHERE question_id = ? AND status = 'approved'
                  ORDER BY created_at ASC
                `).bind(question.id).all(),
                // Get sidebar products
                env.DB.prepare(`
                  SELECT id, title, slug, thumbnail_url, sale_price, normal_price
                  FROM products 
                  WHERE status = 'active'
                  ORDER BY id DESC
                  LIMIT 2 OFFSET ?
                `).bind(Math.max(0, question.id - 1)).all(),
                // Get sidebar blogs
                env.DB.prepare(`
                  SELECT id, title, slug, thumbnail_url, description
                  FROM blogs 
                  WHERE status = 'published'
                  ORDER BY id DESC
                  LIMIT 2 OFFSET ?
                `).bind(Math.max(0, question.id - 1)).all(),
                // Get SEO settings
                getSeoForRequest(env, req, { path })
              ]);
              
              const replies = repliesResult.results || [];
              const sidebar = {
                products: productsResult.results || [],
                blogs: blogsResult.results || []
              };
              
              const htmlRaw = generateForumQuestionHTML(question, replies, sidebar);
              let html = applySeoToHtml(htmlRaw, seo.robots, seo.canonical);

              // Fix 8: Inject QAPage JSON-LD schema
              try {
                const qaSchemaJson = generateQAPageSchema(question, replies, url.origin);
                html = html.replace('</head>', `<script type="application/ld+json">${qaSchemaJson}</script>\n</head>`);
              } catch (_) {}

              // Fix 8: Add OG tags to forum pages
              try {
                const safeForumTitle = (question.title || '').replace(/"/g, '&quot;');
                const forumContentSnippet = (question.content || '').replace(/<[^>]*>/g, '').substring(0, 160).replace(/"/g, '&quot;').replace(/\n/g, ' ');
                const ogTags = `<meta property="og:title" content="${safeForumTitle}">
    <meta property="og:description" content="${forumContentSnippet}">
    <meta property="og:url" content="${seo.canonical}">
    <meta property="og:type" content="website">`;
                html = html.replace('</head>', `${ogTags}\n</head>`);
              } catch (_) {}

              // Fix 8: Fix description meta to use actual content snippet
              try {
                const contentSnippet = (question.content || '').replace(/<[^>]*>/g, '').substring(0, 160).replace(/"/g, '&quot;').replace(/\n/g, ' ');
                const safeQTitle = (question.title || '').replace(/"/g, '&quot;');
                html = html.replace(
                  `<meta name="description" content="${safeQTitle}">`,
                  `<meta name="description" content="${contentSnippet || safeQTitle}">`
                );
              } catch (_) {}

              // Fix 9: Add BreadcrumbList to forum pages
              try {
                const breadcrumbJson = generateBreadcrumbSchema([
                  { name: 'Home', url: url.origin },
                  { name: 'Forum', url: `${url.origin}/forum` },
                  { name: question.title || '', url: seo.canonical }
                ]);
                html = html.replace('</head>', `<script type="application/ld+json">${breadcrumbJson}</script>\n</head>`);
              } catch (_) {}

              // Inject analytics scripts and verification meta tags
              try {
                html = await injectAnalyticsAndMeta(env, html);
              } catch (e) {}

              const resp = new Response(html, {
                status: 200,
                headers: {
                  'Content-Type': 'text/html; charset=utf-8',
                  'X-Worker-Version': VERSION,
                  'X-Robots-Tag': seo.robots,
                  'Cache-Control': 'public, max-age=120'
                }
              });
              // Put into cache for GET requests
              if (method === 'GET' && caches && caches.default) {
                try {
                  const cacheKey = new Request(req.url, { method: 'GET' });
                  await caches.default.put(cacheKey, resp.clone());
                } catch (err) {
                  console.warn('Forum cache put error:', err);
                }
              }
              return resp;
            }
          } catch (e) {
            console.error('Forum question fetch error:', e);
          }
        }
      }

      // ----- API ROUTES -----
      if (path.startsWith('/api/') || path === '/submit-order') {
        const apiResponse = await routeApiRequest(req, env, url, path, method);
        if (apiResponse) return apiResponse;
      }

      // ----- SECURE DOWNLOAD -----
      if (path.startsWith('/download/')) {
        const orderId = path.split('/').pop();
        return handleSecureDownload(env, orderId, url.origin);
      }

      // ----- ADMIN SPA ROUTING -----
      // Handle both /admin and /admin/ and all admin sub-routes
      if ((path === '/admin' || path.startsWith('/admin/')) && !path.startsWith('/api/')) {
        // These standalone pages should be served directly from assets
        const standaloneAdminPages = [
          '/admin/product-form.html',
          '/admin/blog-form.html',
          '/admin/page-builder.html',
          '/admin/landing-builder.html',
          '/admin/migrate-reviews.html'
        ];
        
        if (standaloneAdminPages.includes(path)) {
          // Serve these pages directly from assets
          if (env.ASSETS) {
            const assetResp = await env.ASSETS.fetch(new Request(new URL(path, req.url)));
            const headers = new Headers(assetResp.headers); headers.set('Alt-Svc', 'clear');
            headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
            headers.set('Pragma', 'no-cache');
            headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
            return new Response(assetResp.body, { status: assetResp.status, headers });
          }
        } else {
          // Serve the main dashboard.html for all other admin routes
          // This includes: /admin, /admin/, /admin/dashboard.html, /admin/orders.html, etc.
          if (env.ASSETS) {
            const assetResp = await env.ASSETS.fetch(new Request(new URL('/admin/dashboard.html', req.url)));
            const headers = new Headers(assetResp.headers); headers.set('Alt-Svc', 'clear');
            headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
            headers.set('Pragma', 'no-cache');
            headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
            return new Response(assetResp.body, { status: assetResp.status, headers });
          }
        }
      }

      // ----- DYNAMIC PAGES -----
      // Support both clean URLs (/forum) and .html URLs (/forum.html)
      // Instead of redirecting .html to clean URLs, we attempt to serve
      // dynamic pages directly when a matching slug exists in the database.
      const coreStaticPages = ['index', 'products-grid', 'product', 'buyer-order', 'order-detail', 'order-success', 'success', 'checkout', 'page-builder'];
      
      // Check for .html extension and attempt to serve a dynamic page when a slug exists.
      if (path.endsWith('.html') && !path.includes('/admin/') && !path.startsWith('/admin') && !path.startsWith('/blog/') && !path.startsWith('/forum/')) {
        const slug = path.slice(1).replace(/\.html$/, '');
        // Only attempt to serve non-core pages via the database
        if (!coreStaticPages.includes(slug) && canLookupDynamicSlug(slug)) {
          try {
            if (env.DB) {
              await initDB(env);
              const row = await env.DB.prepare('SELECT content FROM pages WHERE slug = ? AND status = ?').bind(slug, 'published').first();
              if (row && row.content) {
                // Serve the dynamic page content directly instead of redirecting.
                let html = row.content;
                // Inject global components script for header/footer if missing.
                if (html.includes('<body') && !html.includes('global-components.js')) {
                  html = html.replace(/<body([^>]*)>/i, '<body$1>\n<script src="/js/global-components.js"></script>');
                }
                // Apply SEO tags if available.
                try {
                  const seo = await getSeoForRequest(env, req, { path: '/' + slug });
                  html = applySeoToHtml(html, seo.robots, seo.canonical);
                } catch (e) {}
                // Inject analytics and verification tags on dynamic pages
                try {
                  html = await injectAnalyticsAndMeta(env, html);
                } catch (_) {}
                return new Response(html, {
                  status: 200,
                  headers: {
                    'Content-Type': 'text/html; charset=utf-8',
                    'X-Worker-Version': VERSION
                  }
                });
              }
            }
          } catch (e) {
            // Continue to static assets if dynamic lookup fails
          }
        }
      }
      
      // Serve dynamic pages with clean URLs (no .html)
      if (!path.includes('.') && !path.includes('/admin') && !path.startsWith('/api/') && path !== '/' && !path.startsWith('/blog/') && !path.startsWith('/forum/') && !path.startsWith('/product-') && !path.startsWith('/download/')) {
        const slug = path.slice(1).replace(/\/$/, ''); // Remove leading slash and trailing slash
        if (slug && !coreStaticPages.includes(slug) && canLookupDynamicSlug(slug)) {
          try {
            if (env.DB) {
              await initDB(env);
              const row = await env.DB.prepare('SELECT content FROM pages WHERE slug = ? AND status = ?').bind(slug, 'published').first();
              if (row && row.content) {
                // Inject global components script for header/footer
                let html = row.content;
                if (html.includes('<body') && !html.includes('global-components.js')) {
                  html = html.replace(/<body([^>]*)>/i, '<body$1>\n<script src="/js/global-components.js"></script>');
                }
                
                // Apply SEO
                try {
                  const seo = await getSeoForRequest(env, req, { path: '/' + slug });
                  html = applySeoToHtml(html, seo.robots, seo.canonical);
                } catch (e) {}
                // Inject analytics and verification tags on dynamic pages
                try {
                  html = await injectAnalyticsAndMeta(env, html);
                } catch (_) {}
                
                return new Response(html, {
                  status: 200,
                  headers: { 
                    'Content-Type': 'text/html; charset=utf-8',
                    'X-Worker-Version': VERSION
                  }
                });
              }
            }
          } catch (e) {
            // continue to static assets
          }
        }
      }

      // ----- HTML ASSET MAPPINGS -----
      // Certain `.html` routes should serve a different static file directly
      // rather than redirecting.  This avoids broken links when no database
      // is configured and eliminates unnecessary redirects for end users.
      if (method === 'GET' || method === 'HEAD') {
        const htmlAssetTargets = {
          // Map `/products.html` to the existing grid file; this file lives in
          // the static assets folder and can be served without DB access.
          '/products.html': '/products-grid.html',
          '/checkout': '/checkout.html',
          '/checkout/': '/checkout.html',
          '/checkout/index.html': '/checkout.html',
          // Map blog and forum to their index files so these archives load
          // without needing to redirect to `/blog` or `/forum`.
          '/blog.html': '/blog/index.html',
          '/forum.html': '/forum/index.html'
        };

        const target = htmlAssetTargets[path];
        if (target) {
          // Serve the target asset directly from the ASSETS KV.  We mirror
          // the header behaviour used elsewhere in the router.
          if (env.ASSETS) {
            const assetResp = await env.ASSETS.fetch(new Request(new URL(target, req.url)));
            const headers = new Headers(assetResp.headers);
            headers.set('Alt-Svc', 'clear');
            headers.set('X-Worker-Version', VERSION);
            return new Response(assetResp.body, {
              status: assetResp.status,
              headers
            });
          }
        }
      }

      // ----- DEFAULT PAGE ROUTING -----
      // Check for default pages and serve them instead of static files
      if ((method === 'GET' || method === 'HEAD') && env.DB) {
        let defaultPageType = null;
        
        // Home page
        if (path === '/' || path === '/index.html') {
          defaultPageType = 'home';
        }
        // Blog archive
        else if (path === '/blog/' || path === '/blog/index.html' || path === '/blog' || path === '/blog.html') {
          defaultPageType = 'blog_archive';
        }
        // Forum archive
        else if (path === '/forum/' || path === '/forum/index.html' || path === '/forum' || path === '/forum.html') {
          defaultPageType = 'forum_archive';
        }
        // Product grid
        else if (path === '/products/' || path === '/products/index.html' || path === '/products' || path === '/products-grid.html' || path === '/products.html') {
          defaultPageType = 'product_grid';
        }
        
        if (defaultPageType) {
          try {
            await initDB(env);
            const defaultPage = await env.DB.prepare(
              'SELECT content FROM pages WHERE page_type = ? AND is_default = 1 AND status = ?'
            ).bind(defaultPageType, 'published').first();
            
            if (defaultPage && defaultPage.content) {
              // Inject global components script for header/footer
              let html = defaultPage.content;
              if (html.includes('<body') && !html.includes('global-components.js')) {
                html = html.replace(/<body([^>]*)>/i, '<body$1>\n<script src="/js/global-components.js"></script>');
              }

              // Apply SEO tags (robots, canonical)
              const responseHeaders = {
                'Content-Type': 'text/html; charset=utf-8',
                'X-Worker-Version': VERSION,
                'X-Default-Page': defaultPageType
              };
              try {
                const seo = await getSeoForRequest(env, req, { path });
                html = applySeoToHtml(html, seo.robots, seo.canonical);
                responseHeaders['X-Robots-Tag'] = seo.robots;
                // Add noindex tags if needed
                const noindexTags = await getNoindexMetaTags(env, path);
                if (noindexTags) {
                  html = html.replace(/<\/head>/i, `\n    ${noindexTags}\n  </head>`);
                }
                // Inject analytics and verification tags
                try {
                  html = await injectAnalyticsAndMeta(env, html);
                } catch (_) {}
                // Homepage: inject Organization + WebSite schema
                if (defaultPageType === 'home') {
                  try {
                    const seoResp = await getMinimalSEOSettings(env);
                    let seoSettings = {};
                    if (seoResp && typeof seoResp.json === 'function') {
                      const parsed = await seoResp.json();
                      seoSettings = (parsed && parsed.settings) || {};
                    }
                    if (!seoSettings.site_url) seoSettings.site_url = url.origin;
                    if (!seoSettings.site_title) seoSettings.site_title = 'WishVideo';
                    const orgSchema = generateOrganizationSchema(seoSettings);
                    const siteSchema = generateWebSiteSchema(seoSettings);
                    html = html.replace(/<\/head>/i, `<script type="application/ld+json">${orgSchema}</script>\n<script type="application/ld+json">${siteSchema}</script>\n</head>`);
                  } catch (_) {}
                }
              } catch (e) {
                // ignore SEO injection errors
              }

              return new Response(html, {
                status: 200,
                headers: responseHeaders
              });
            }
          } catch (e) {
            console.error('Default page error:', e);
            // Continue to static assets
          }
        }
      }

      // ----- STATIC ASSETS WITH SERVER-SIDE SCHEMA INJECTION & CACHING -----
      if (env.ASSETS) {
        let assetReq = req;
        let assetPath = path;
        let schemaProductId = null;
        let schemaProduct = null;

        // Canonical product URLs: /product-<id>/<slug>
        if ((method === 'GET' || method === 'HEAD')) {
          const canonicalMatch = assetPath.match(/^\/product-(\d+)\/(.+)$/);
          if (canonicalMatch) {
            const pid = Number(canonicalMatch[1]);
            if (!Number.isNaN(pid)) {
              schemaProductId = pid;
              const rewritten = new URL(req.url);
              rewritten.pathname = '/_product_template.tpl';
              rewritten.searchParams.set('id', String(schemaProductId));
              assetReq = new Request(rewritten.toString(), req);
              assetPath = '/_product_template.tpl';
            }
          }
        }

        const assetResp = await env.ASSETS.fetch(assetReq);
        
        const contentType = assetResp.headers.get('content-type') || '';
        const isHTML = contentType.includes('text/html') || assetPath === '/_product_template.tpl';
        const isSuccess = assetResp.status === 200;
        
        // Caching: Only cache HTML pages, never admin routes
        const shouldCache = isHTML && isSuccess && !path.startsWith('/admin') && !path.includes('/admin/');
        const cacheKey = new Request(req.url, { 
          method: 'GET',
          headers: { 'Accept': 'text/html' }
        });

        if (shouldCache) {
          try {
            // Check cache first
            const cachedResponse = await caches.default.match(cacheKey);
            if (cachedResponse) {
              const headers = new Headers(cachedResponse.headers);
              headers.set('X-Cache', 'HIT');
              headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
              return new Response(cachedResponse.body, { 
                status: cachedResponse.status, 
                headers 
              });
            }
          } catch (cacheError) {
            // Continue with normal processing if cache fails
          }
        }
        
        if (isHTML && isSuccess) {
          try {
            const baseUrl = url.origin;
            let html = await assetResp.text();
            
            // Product detail page - inject individual product schema
            if (assetPath === '/_product_template.tpl' || assetPath === '/product.html' || assetPath === '/product') {
              const productId = schemaProductId ? String(schemaProductId) : url.searchParams.get('id');
              if (productId && env.DB) {
                await initDB(env);
                
                // OPTIMIZED: Run both queries in parallel
                const [productResult, reviewsResult] = await Promise.all([
                  env.DB.prepare(`
                    SELECT p.*, 
                      COUNT(r.id) as review_count, 
                      AVG(r.rating) as rating_average
                    FROM products p
                    LEFT JOIN reviews r ON p.id = r.product_id AND r.status = 'approved'
                    WHERE p.id = ?
                    GROUP BY p.id
                  `).bind(Number(productId)).first(),
                  env.DB.prepare(
                    'SELECT * FROM reviews WHERE product_id = ? AND status = ? ORDER BY created_at DESC LIMIT 5'
                  ).bind(Number(productId), 'approved').all()
                ]);
                
                const product = productResult;
                if (product) {
                  schemaProduct = product;
                  const reviews = reviewsResult.results || [];
                  const schemaJson = generateProductSchema(product, baseUrl, reviews);
                  html = injectSchemaIntoHTML(html, 'product-schema', schemaJson);
                  
                  // Inject VideoObject schema for video rich results
                  const videoSchemaJson = generateVideoSchema(product, baseUrl);
                  if (videoSchemaJson && videoSchemaJson !== '{}') {
                    const videoSchemaTag = `<script type="application/ld+json" id="video-schema">${videoSchemaJson}</script>`;
                    html = html.replace('</head>', `${videoSchemaTag}\n</head>`);
                  }
                  
                  // Add video meta tags for social sharing and SEO
                  if (product.video_url || product.preview_video_url) {
                    const videoUrl = product.video_url || product.preview_video_url;
                    const videoMetaTags = `
    <meta property="og:type" content="video.other">
    <meta property="og:video" content="${videoUrl}">
    <meta property="og:video:url" content="${videoUrl}">
    <meta property="og:video:secure_url" content="${videoUrl}">
    <meta property="og:video:type" content="video/mp4">
    <meta property="og:video:width" content="1280">
    <meta property="og:video:height" content="720">
    <meta name="twitter:card" content="player">
    <meta name="twitter:player" content="${videoUrl}">
    <meta name="twitter:player:width" content="1280">
    <meta name="twitter:player:height" content="720">`;
                    html = html.replace('</head>', `${videoMetaTags}\n</head>`);
                  }
                  
                  // LCP Optimization: Preload hero image for faster rendering
                  if (product.thumbnail_url) {
                    let lcpImageUrl = product.thumbnail_url;
                    // Optimize Cloudinary URLs
                    if (lcpImageUrl.includes('res.cloudinary.com')) {
                      lcpImageUrl = lcpImageUrl.replace(
                        /(https:\/\/res\.cloudinary\.com\/[^/]+\/image\/upload\/)(.*)/,
                        '$1f_auto,q_auto,w_800/$2'
                      );
                    }
                    const preloadTag = `<link rel="preload" as="image" href="${lcpImageUrl}" fetchpriority="high">`;
                    html = html.replace('</head>', `${preloadTag}\n</head>`);
                  }
                  
                  // Inject SEO meta tags
                  // Prefer SEO-specific fields when provided; fall back to generic title/description
                  const safeTitle = (product.seo_title || product.title || '').replace(/"/g, '&quot;');
                  const safeDesc = (product.seo_description || product.description || '').substring(0, 160).replace(/"/g, '&quot;').replace(/\n/g, ' ');
                  const safeKeywords = (product.seo_keywords || '').replace(/"/g, '&quot;');
                  // Title tag
                  html = html.replace('<title>Loading Product... | WishVideo</title>', `<title>${safeTitle} | WishVideo</title>`);
                  // Open Graph title/description and image
                  html = html.replace('<meta property="og:title" content="Loading...">', `<meta property="og:title" content="${safeTitle}">`);
                  html = html.replace('<meta property="og:description" content="">', `<meta property="og:description" content="${safeDesc}">`);
                  html = html.replace('<meta property="og:image" content="">', `<meta property="og:image" content="${product.thumbnail_url || ''}">`);
                  // Description tag
                  html = html.replace('<meta name="description" content="Custom personalized video greetings from Africa.">', `<meta name="description" content="${safeDesc}">`);
                  // Keywords tag (if provided, override default keywords)
                  html = html.replace('<meta name="keywords" content="video, greeting, birthday, wish, africa">', `<meta name="keywords" content="${safeKeywords}">`);

                  // Fix 6: Add og:url to product pages
                  try {
                    const productSeo = await getSeoForRequest(env, req, { product });
                    const ogUrlTag = `<meta property="og:url" content="${productSeo.canonical}">`;
                    html = html.replace('</head>', `${ogUrlTag}\n</head>`);

                    // Fix 9: Add BreadcrumbList schema to product pages
                    const breadcrumbJson = generateBreadcrumbSchema([
                      { name: 'Home', url: baseUrl },
                      { name: 'Products', url: `${baseUrl}/products` },
                      { name: product.title || '', url: productSeo.canonical }
                    ]);
                    html = html.replace('</head>', `<script type="application/ld+json">${breadcrumbJson}</script>\n</head>`);
                  } catch (_) {}
                }
              }
            }
            
            // Collection page - inject product list schema
            if (assetPath === '/index.html' || assetPath === '/' || assetPath === '/products.html' || assetPath === '/products-grid.html') {
              if (env.DB) {
                await initDB(env);
                const productsResult = await env.DB.prepare(`
                  SELECT p.*,
                    (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND status = 'approved') as review_count,
                    (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND status = 'approved') as rating_average
                  FROM products p
                  WHERE p.status = 'active'
                  ORDER BY p.sort_order ASC, p.id DESC
                `).all();
                
                const products = productsResult.results || [];
                if (products.length > 0) {
                  const schemaJson = generateCollectionSchema(products, baseUrl);
                  html = injectSchemaIntoHTML(html, 'collection-schema', schemaJson);
                }
              }

              // Fix 10: Inject Organization + WebSite schema on homepage
              if (assetPath === '/index.html' || assetPath === '/') {
                try {
                  const seoResp2 = await getMinimalSEOSettings(env);
                  let seoSettings2 = {};
                  if (seoResp2 && typeof seoResp2.json === 'function') {
                    const parsed2 = await seoResp2.json();
                    seoSettings2 = (parsed2 && parsed2.settings) || {};
                  }
                  if (!seoSettings2.site_url) seoSettings2.site_url = baseUrl;
                  if (!seoSettings2.site_title) seoSettings2.site_title = 'WishVideo';
                  const orgSchema = generateOrganizationSchema(seoSettings2);
                  const siteSchema = generateWebSiteSchema(seoSettings2);
                  html = html.replace(/<\/head>/i, `<script type="application/ld+json">${orgSchema}</script>\n<script type="application/ld+json">${siteSchema}</script>\n</head>`);
                } catch (_) {}
              }
            }
            
            const headers = new Headers(); headers.set('Alt-Svc', 'clear');
            headers.set('Content-Type', 'text/html; charset=utf-8');
            headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
            headers.set('X-Cache', 'MISS');

            // Apply Robots + Canonical (admin controlled)
            if (!isAdminUI && !isAdminAPI) {
              try {
                const seo = await getSeoForRequest(env, req, schemaProduct ? { product: schemaProduct } : { path });
                html = applySeoToHtml(html, seo.robots, seo.canonical);
                headers.set('X-Robots-Tag', seo.robots);
                
                // Add noindex tags for hidden pages (user-controlled hiding from search)
                const noindexTags = await getNoindexMetaTags(env, path);
                if (noindexTags) {
                  html = html.replace('</head>', `\n    ${noindexTags}\n  </head>`);
                }
                // Inject analytics and verification tags after SEO and noindex
                try {
                  html = await injectAnalyticsAndMeta(env, html);
                } catch (_) {}
              } catch (e) {
                // ignore SEO injection errors
              }
            }
            
            const response = new Response(html, { status: 200, headers });
            
            // Cache the response for non-admin pages (5 minutes TTL)
            if (shouldCache) {
              try {
                const cacheResponse = new Response(html, {
                  status: 200,
                  headers: {
                    'Content-Type': 'text/html; charset=utf-8',
                    'Cache-Control': 'public, max-age=300', // 5 minutes
                    'X-Worker-Version': VERSION,
                    'X-Cache-Created': new Date().toISOString()
                  }
                });
                
                // Store in cache asynchronously
                ctx.waitUntil(caches.default.put(cacheKey, cacheResponse));
                console.log('Cached response for:', req.url);
              } catch (cacheError) {
                console.warn('Cache storage failed:', cacheError);
                // Continue even if caching fails
              }
            }
            
            return response;
          } catch (e) {
            console.error('Schema injection error:', e);
          }
        }
        
        // For non-HTML or failed schema injection, just pass through with version header
        const headers = new Headers(assetResp.headers); headers.set('Alt-Svc', 'clear');
        headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
        headers.set('Pragma', 'no-cache');
        headers.set('X-Worker-Version', VERSION); headers.set('Alt-Svc', 'clear');
        
        return new Response(assetResp.body, { status: assetResp.status, headers });
      }

      return new Response('Not found', {
        status: 404,
        headers: {
          'Cache-Control': 'public, max-age=60',
          'X-Worker-Version': VERSION
        }
      });
    } catch (e) {
      console.error('Worker error:', e);

      // Check if it's a timeout/connection error (cold start issue)
      const isTimeoutError = e.message?.includes('timeout') || e.message?.includes('abort');
      const isConnectionError = e.message?.includes('connection') || e.message?.includes('network');

      if (isTimeoutError || isConnectionError) {
        // Return 503 with Retry-After header for cold start issues
        return new Response(JSON.stringify({
          error: 'Service temporarily unavailable. Please retry.',
          code: 'COLD_START_RETRY'
        }), {
          status: 503,
          headers: {
            ...CORS,
            'Content-Type': 'application/json',
            'Retry-After': '2',
            'Cache-Control': 'no-store'
          }
        });
      }

      return new Response(JSON.stringify({ error: e.message }), {
        status: 500,
        headers: { ...CORS, 'Content-Type': 'application/json' }
      });
    }
  },

  // Scheduled handler for cron jobs
  // WARMING: This runs every 5 minutes (configure in wrangler.toml)
  // Keeps DB connection warm and prevents cold start issues
  async scheduled(event, env, ctx) {
    setVersion(env.VERSION);
    console.log('Cron job started:', event.cron, 'at', new Date().toISOString());

    try {
      if (env.DB) {
        // WARMUP: Initialize DB tables if needed
        await initDB(env);

        // DAILY BACKUP + EMAIL/WEBHOOK (2 AM)
        if (event.cron === '0 2 * * *') {
          try {
            // createBackup() handles: store in R2 + D1 metadata + webhook dispatch + optional email
            const baseUrl = env.PUBLIC_BASE_URL || env.SITE_URL || env.BASE_URL || null;
            const backupResp = await createBackupApi(env, { trigger: 'cron', base_url: baseUrl });
            if (!backupResp?.ok) {
              const errBody = await backupResp.text().catch(() => '');
              console.log('Daily backup API returned non-OK:', backupResp?.status, errBody);
            } else {
              const payload = await backupResp.clone().json().catch(() => ({}));
              console.log('Daily backup created:', payload?.id || 'unknown-id');
            }
          } catch (e) {
            console.log('Daily backup failed:', e?.message || e);
          }
        }


        // WARMUP: Multiple queries to ensure full connection warmth
        // Added more tables for comprehensive warming
        await Promise.all([
          env.DB.prepare('SELECT 1 as warm').first(),
          env.DB.prepare('SELECT COUNT(*) as count FROM products WHERE status = ?').bind('active').first(),
          env.DB.prepare('SELECT COUNT(*) as count FROM orders').first(),
          env.DB.prepare('SELECT COUNT(*) as count FROM reviews').first(),
          env.DB.prepare('SELECT COUNT(*) as count FROM blogs WHERE status = ?').bind('published').first().catch(() => null),
          env.DB.prepare('SELECT COUNT(*) as count FROM forum_questions').first().catch(() => null)
        ]);
        console.log('DB connection warmed successfully with multiple queries');

        // Cleanup expired Whop checkout sessions (daily cron only)
        // The 5-minute cron is intended for warming; cleanup is heavier and can increase subrequests/wall time.
        if (event.cron === '0 2 * * *') {
          const result = await cleanupExpired(env);
          try {
            const data = await result.json();
            console.log('Cleanup result:', data);
          } catch (_) {
            console.log('Cleanup finished (non-JSON response)');
          }
        }
      }
    } catch (e) {
      console.error('Cron job error:', e);
    }
  }
};
